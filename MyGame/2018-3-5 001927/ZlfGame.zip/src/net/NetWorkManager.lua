NetworkStatus = {}
NetworkStatus.INIT = 1
NetworkStatus.CONNECTED = 2
NetworkStatus.CONNECT_LOST = 3
NetworkStatus.BEGIN_CONNECT = 4

local lpack = require "pack"


NetWorkManager = class( "NetWorkManager" )

local m_instance = nil

function NetWorkManager:getInstance()
	if m_instance == nil then
		m_instance = NetWorkManager.new()
	end
	return m_instance
end

function NetWorkManager:initNetWorkEvent()
	Notifier.register( "onRecv" , self.onRecv , self )
	Notifier.register( "update_network_status" , self.onUpdate , self )
	local ret = NetworkManager:getInstance():initNetwork()
	if ret == 0 then
		NetworkManager:getInstance():connect( IP , PORT )
	end
end

function onRecive( tag , data )
	Notifier.dispatch( "onRecv" , data )
end

function onLuaEvent( msg_txt )
	Notifier.dispatch( msg_txt )
end

function NetWorkManager:onRecv( data )
	print( "recv     " , data )
	-- ComponentMgr:showAlert(data)
	-- local protoData = json.decode( data )
	-- local protoNo = protoData.id
	-- Notifier.dispatch( protoNo .. "NetEventFunc" , protoData )

	-- local buff = Utils.decode(data)
	-- local byteArray = ByteArray.new()
 --    byteArray:writeBytes(data)

    -- byteArray:writeInt(string.len(buffer))
    -- byteArray:writeInt(mId)
    -- byteArray:writeInt(cmd)
    -- byteArray:writeBytes(buffer)

	-- local len = byteArray:readInt()
	-- print( len )
	-- local bId = byteArray:readInt()
	-- local mId = byteArray:readInt()
	-- local body = byteArray:readBytes()
	-- local protoData = protobuf.decode("P" .. bId .. ".P" .. mId .. ".C2S" , body)
	-- dump( protoData )
end

function NetWorkManager:onUpdate()
	local status = NetworkManager:getInstance():getNetworkStatus()
	if status == NetworkStatus.CONNECT_LOST then
		local function reconnect()
			print("开始连接服务器")
			NetworkManager:getInstance():connect( IP , PORT )
		end
		Notifier.dispatch( CmdName.MsgBox , { txt = "网络已断开，请检查网络后重新连接！" , sureBtnName = "连接" , sure = reconnect } )
	end
end

function NetWorkManager:registerProto( bId )
	if type(bId) ~= "number" then
		return false
	end
	local fileUtils = cc.FileUtils:getInstance()
	local pbName = "P" .. bId .. ".pb" 
	local path = fileUtils:fullPathForFilename( pbName )
	if path == nil or path == "" then
		return false
	end
    local fileData = fileUtils:getStringFromFile( path )
    protobuf.register( fileData )
    return true
end

function NetWorkManager:sendProto(data , len)
	-- local isCanSend = self:registerProto(mId)
	-- if not isCanSend then	
	-- 	return
	-- end
	-- if self._lastTime ~= nil and self._oldProtoCode ~= nil then
	-- 	local Intervaltime = os.time() - self._lastTime
	-- 	Intervaltime = Intervaltime / 10
	-- 	local protoCode = "P" .. mId .. ".P" .. cmd .. ".C2S"
	-- 	if Intervaltime <= 0.1 and self._oldProtoCode == protoCode then
	-- 		print("小于100毫秒重复发送同一条协议，禁止")
	-- 		return
	-- 	end
	-- end
	-- self._lastTime = os.time()
	-- self._oldProtoCode = "P" .. mId .. ".P" .. cmd .. ".C2S"
	-- local snedData = {}
 --    snedData.moduleId = mId
 --    snedData.cmdId = cmd
 --    snedData.obj = data
	-- local buffer = protobuf.encode("P" .. mId .. ".P" .. cmd .. ".C2S" , data)
	-- local ByteArray = require("ByteArray")
	-- local byteArray = ByteArray.new()
	-- byteArray:writeUInt(string.len(buffer))
 --    byteArray:writeUInt(mId)
 --    byteArray:writeUInt(cmd)
 --    byteArray:writeStringUShort(buffer)
 --    print( byteArray:getBytes() , byteArray:getLen() )
 --    -- print( mId )
 --    -- print( cmd )
 --    -- print( buffer )

 --    print( byteArray:readUInt() )
    -- print( byteArray:readUInt() )
    -- print( byteArray:readUInt() )
    -- print( byteArray:readStringUShort() )

    -- local protoData = byteArray:toString()
    -- Net:getInstance():sendProto( protoData )



    -- local str = Utils.encode( protoData )


 -- 	local w = {id = mId , name = "zlf" , pwd = "12345"}
	-- local str = json.encode( w )

	-- data.id = protoId
	-- local str = json.encode( data )
	

    NetworkManager:getInstance():sendProto(1, data , len )
end