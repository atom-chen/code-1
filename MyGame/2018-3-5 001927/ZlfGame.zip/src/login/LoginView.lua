LoginView = class("LoginView", LayerBase)

LoginView.animation = true
LoginView.config = LayerConfig.life

function LoginView:create()
	local ret = LoginView.new()
	return ret
end

function LoginView:init()

end

function LoginView:open()
end

function LoginView:close()
	LayerCtrol:getInstance():close(self.name)
end