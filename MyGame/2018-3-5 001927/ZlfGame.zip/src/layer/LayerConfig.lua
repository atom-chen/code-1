LayerConfig = LayerConfig or {}

LayerConfig.destory = 1 --关闭立即销毁

LayerConfig.delay = 2 --延时销毁

LayerConfig.life = 3 --不销毁

LayerConfig.fullScreen = 4 --全屏

LayerConfig.halfSize = 5 --半屏

LayerConfig.delayTime = 3000 --延迟多久释放