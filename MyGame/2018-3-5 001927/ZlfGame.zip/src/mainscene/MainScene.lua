MainScene = class("MainScene", LayerBase)

MainScene.animation = false
MainScene.config = LayerConfig.life

function MainScene:create()
	local ret = MainScene.new()
	return ret
end

function MainScene:init()
	local msgpack = require "MessagePack"
	msgpack.set_number'float'
	msgpack.set_integer'unsigned'
	msgpack.set_array'with_hole'
	msgpack.set_string'string'
	local icon = ccui.ImageView:create()
	icon:loadTexture( "ui/head_icon_bg.png" )
	icon:setPosition( 460 , 360 )
	self:addChild( icon )

	ComponentMgr:addTouch( icon , function()
		local tab = { a = 1.89, b = 'b' }
		local s = msgpack.pack(tab)
		print( "send" )
		NetWorkManager:getInstance():sendProto( s , string.len( s ) )
	end )
end

function MainScene:open()
end

function MainScene:close()
	LayerCtrol:getInstance():close(self.name)
end