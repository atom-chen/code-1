local effect_data = {}
local item
local anim_infoList = {}
effect_data["anim_info"] = anim_infoList

item = {}
item.id = 1
item.path = "grossini_dance_0%d.png"
item.time = 100
item.loop = -1
item.index = 1
item.uitype = 0
anim_infoList[1] = item


return effect_data
