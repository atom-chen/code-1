isUpdate = isUpdate or {}
isUpdate.flag = false
return isUpdate