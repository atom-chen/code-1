CmdName = CmdName or {}

CmdName.useLocal = 0
CmdName.usePlist = 1

CmdName.LoninScene = "LoninScene"
CmdName.UpdateScene = "UpdateScene"
CmdName.MainScene = "MainScene"

CmdName.MsgBox = "MsgBox"

CmdName.Update = "UpdateView"
CmdName.PkgPath = "https://raw.githubusercontent.com/zlf921026/code/testUpdate/testUpdate.zip"
CmdName.VerSionPath = "https://raw.githubusercontent.com/zlf921026/code/testUpdate/version"

CmdName.LoginView = "LoginView"
CmdName.UpdateView = "UpdateView"
