#ifndef __LUA_PBC_H_
#define __LUA_PBC_H_

#if __cplusplus

extern "C" {

#endif



#include "lauxlib.h"



	int luaopen_protobuf_c(lua_State *L);



#if __cplusplus

}

#endif
#endif