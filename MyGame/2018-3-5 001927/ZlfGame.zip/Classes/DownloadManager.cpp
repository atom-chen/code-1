#include "DownloadManager.h"
using namespace network;

DownloadManager* DownloadManager::m_pInstance = nullptr;

DownloadManager::DownloadManager()
	:m_downing(false),
	m_path("")
{
	m_down_list.clear();
}

DownloadManager::~DownloadManager()
{
	if ( m_pInstance )
	{
		delete m_pInstance;
		m_pInstance = nullptr;
	}
}

void DownloadManager::addDownTask( std::string save_name , std::string img_url )
{
	if ( img_url == "" )
	{
		return;
	}
	if ( save_name == "" )
	{
		save_name = "down_img.png";
	}
	down_dt dt;
	dt.down_url = img_url;
	dt.name = FileUtils::getInstance()->getWritablePath() + save_name;
	m_down_list.push_back(dt);
	if (!m_downing)
	{
		//start();
	}
}

void DownloadManager::downImg( std::string save_name , std::string img_url )
{
	if ( img_url == "" )
	{
		return;
	}
	if ( save_name == "" )
	{
		save_name = "down_img.png";
	}
	m_path = FileUtils::getInstance()->getWritablePath() + save_name;
	HttpRequest* request = new HttpRequest();
	request->setUrl( m_path.c_str() );
	request->setRequestType(HttpRequest::Type::GET);
	request->setResponseCallback(CC_CALLBACK_2(DownloadManager::onCompleted, this));
	request->setTag("GET img1");
	HttpClient::getInstance()->send(request);
	request->release();
}

void DownloadManager::start()
{
	m_downing = true;
	down_dt dt = m_down_list.front();
	std::string down_url = dt.down_url;
	m_path = dt.name;
	HttpRequest* request = new HttpRequest();
	request->setUrl( down_url.c_str() );
	request->setRequestType(HttpRequest::Type::GET);
	request->setResponseCallback(CC_CALLBACK_2(DownloadManager::onCompleted, this));
	request->setTag("GET img1");
	HttpClient::getInstance()->send(request);
	request->release();
}

void DownloadManager::onCompleted( HttpClient* sender, HttpResponse* response )
{
	if (!response)
	{
		if (!m_down_list.empty())
		{
			start();
		}
		else
		{
			m_downing = false;
		}
		return;
	}
	if (0 != strlen(response->getHttpRequest()->getTag())) 
	{
		log("%s completed", response->getHttpRequest()->getTag());
	}
	long statusCode = response->getResponseCode();
	if (!response->isSucceed()) 
	{
		log("response failed");
		log("error buffer: %s", response->getErrorBuffer());
		if (!m_down_list.empty())
		{
			start();
		}
		else
		{
			m_downing = false;
		}
		return;
	}
	std::vector<char> *buffer = response->getResponseData();
	Image* img = new Image;
	img->initWithImageData((unsigned char*)buffer->data(),buffer->size());
	if (m_path == "")
	{
		m_path = FileUtils::getInstance()->getWritablePath() + "down_load.png";
	}
	if (img->saveToFile(m_path.c_str() , false))
	{
		m_down_list.erase( m_down_list.begin() );
		delete img;
	}
	if (!m_down_list.empty())
	{
		start();
	}
	else
	{
		m_downing = false;
	}
}