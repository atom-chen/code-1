#include "SendThread.h"
#include "NetWorkManager.h"
#include "cocos2d.h"
USING_NS_CC;

static void sendThreadFunc(void* ptr)
{
	SendThread* self = (SendThread*)ptr;
	self->handleSend();
}

SendThread::SendThread(BsdSocket* socket):
	_pSocket(socket),
	_keepThread(true),
	_protoDataList(0),
	_retryTimes(0)
{

}

SendThread::~SendThread(void)
{
}

void SendThread::start()
{
	_t = std::thread(sendThreadFunc, this);
	_t.detach(); // �����߳�
}

void SendThread::handleSend()
{
	const static int MAX_RETRY_TIMES = 3;
	while (_keepThread)
	{
		std::unique_lock<std::mutex> ul(_threadMutex);
		//û����Ҫ���͵����ݣ������߳�
		while (_protoDataList.empty())
		{
			_threadCond.wait(ul);
		}
		
		NetworkSendProtoData* protoData = _protoDataList.front();
		char* content = protoData->getContent();
		int size = protoData->getSize();
		int ret = _pSocket->sendData(content, size);
		if (SOCKET_ERROR == ret)
		{
			CCLOG("[network] send protocol error, retry times:%d", _retryTimes);
			if(_retryTimes < MAX_RETRY_TIMES)
			{
				_retryTimes++;
				std::this_thread::sleep_for(std::chrono::milliseconds(500));
			}
			else
			{
				//����ʧ��
				_retryTimes = 0;
				_protoDataList.clear();
				for(NetworkSendProtoData* pd : _protoDataList)
				{
					NetworkManager::getInstance()->recycleSendProtoData(pd);
				}
				NetworkManager::getInstance()->setNetworkStatus(NETWORK_CONNECT_LOST);
				CCLOG("[network] send protocol fail");
				_threadCond.wait(ul);
			}
		}
		else
		{
			CCLOG( "send success" );
			//���ͳɹ�
			_retryTimes = 0;
			_protoDataList.erase(_protoDataList.begin());
			NetworkManager::getInstance()->recycleSendProtoData(protoData);
		}
	}
}
void SendThread::addProto(NetworkSendProtoData* protoData)
{
	CCLOG("addProto");
	std::unique_lock<std::mutex> ul(_threadMutex);
	_protoDataList.push_back(protoData);
	//�����߳�
	_threadCond.notify_all();
}
