#include "base/ccConfig.h"
#ifndef __cocos2dx_network_h__
#define __cocos2dx_network_h__

#ifdef __cplusplus
extern "C" {
#endif
#include "tolua++.h"
#ifdef __cplusplus
}
#endif

int register_all_cocos2dx_network(lua_State* tolua_S);












#endif // __cocos2dx_network_h__
