#include "ProtoData.h"
#include "BsdSocket.h"
#include "message.h"

NetworkProtoData::NetworkProtoData(void):
	_content(nullptr),
	_referenceCount(1),
	protoId(0),
	size(0)
{
	this->reset();
}

NetworkProtoData::~NetworkProtoData(void)
{
	if(_content)
	{
		delete [] _content;
		_content = nullptr;
	}
}

void NetworkProtoData::release()
{
	if(_referenceCount < 0)
		return;

	_referenceCount--;
	if(_referenceCount == 0)
	{
		delete this;
	}
}

void NetworkProtoData::retain()
{
	_referenceCount++;
}

void NetworkProtoData::reset()
{
	size = 0;
	protoId = 0;
}

char* NetworkProtoData::getContent()
{
	return _content;
}

unsigned int NetworkProtoData::getBodySize()
{
	return _bodySize;
}

unsigned int NetworkProtoData::getSize()
{
	return size;
}


NetworkSendProtoData::NetworkSendProtoData()
{
	_content = new char[PROTO_DATA_SEND_BUF_SIZE];
}

NetworkSendProtoData::~NetworkSendProtoData()
{
	if(_content)
	{
		delete [] _content;
		_content = nullptr;
	}
}

NetworkSendProtoData* NetworkSendProtoData::create()
{
	NetworkSendProtoData* p = new NetworkSendProtoData();
	return p;
}

void NetworkSendProtoData::reset()
{
	NetworkProtoData::reset();
	::memset(_content, 0, PROTO_DATA_SEND_BUF_SIZE);
}

void NetworkSendProtoData::fillBody(const char* protoBody, int bodySize)
{

	_bodySize = bodySize;

	unsigned int _fillIndex = 0;

	int nSize = htonl(size);
	::memcpy(_content, &nSize, sizeof(size));
	_fillIndex += sizeof(size);

	short nProtoId = htons(protoId);
	::memcpy(_content + _fillIndex, &nProtoId, sizeof(protoId));
	_fillIndex += sizeof(protoId);

	::memcpy(_content + _fillIndex, protoBody, _bodySize);
	_fillIndex += _bodySize;

	//len����������
	size = _fillIndex;

	//��䳤��
	nSize = htonl((_fillIndex - sizeof(size)));
	::memcpy(_content, &nSize, sizeof(size));
}

char* NetworkSendProtoData::getContent()
{
	return _content;
}


NetworkRecvProtoData::NetworkRecvProtoData():
	_bodyBytes(nullptr)
{
	this->len = PROTO_DATA_RECV_BUF_SIZE;
	_bodyBytes = new char[this->len];
}

NetworkRecvProtoData::NetworkRecvProtoData(unsigned int len)
{
	this->len = len;
	_bodyBytes = new char[len];
}

NetworkRecvProtoData::~NetworkRecvProtoData()
{
	if(_bodyBytes)
	{
		delete [] _bodyBytes;
		_bodyBytes = nullptr;
	}
}

NetworkRecvProtoData* NetworkRecvProtoData::create()
{
	NetworkRecvProtoData* p = new NetworkRecvProtoData();
	return p;
}

NetworkRecvProtoData* NetworkRecvProtoData::create(unsigned int len)
{
	NetworkRecvProtoData* p = new NetworkRecvProtoData(len);
	return p;
}

char* NetworkRecvProtoData::getBodyBytes()
{
	return _bodyBytes;
}

void NetworkRecvProtoData::reset()
{
	NetworkProtoData::reset();
	::memset(_bodyBytes, 0, this->len);
}

void NetworkRecvProtoData::parseBody(const char* buf, unsigned int size)
{
	int parseIndex = 0;

	::memcpy(&protoId, buf + parseIndex, sizeof(protoId));
	protoId = ntohs(protoId);
	parseIndex += sizeof(protoId);

	::memcpy(_bodyBytes, buf + parseIndex, size - parseIndex);
	_bodySize = size - parseIndex;

}