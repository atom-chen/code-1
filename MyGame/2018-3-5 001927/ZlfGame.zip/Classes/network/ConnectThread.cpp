#include "ConnectThread.h"
#include "cocos2d.h"
#include "NetWorkManager.h"
#include "message.h"
USING_NS_CC;

static int connThreadFunc(void* p)
{
	ConnectThread* self = (ConnectThread*)p;
	self->handleConnect();
	return NULL;
}

ConnectThread::ConnectThread(BsdSocket* _ps):
	_pSocket(_ps)
{
}

ConnectThread::~ConnectThread(void)
{
}

void ConnectThread::handleConnect()
{
	int ret = _pSocket->connectServer(_ip.c_str(), _port);
	if(ret == SOCKET_CONNECT_SUCCESS)
	{
		CCLOG("[network] server connect success");
		NetworkManager::getInstance()->setNetworkStatus(NETWORK_CONNECTED);
	}
	else
	{
		CCLOG("[network] server connect fail");
		NetworkManager::getInstance()->setNetworkStatus(NETWORK_CONNECT_LOST);
	}
}

void ConnectThread::start(const std::string& ip, int port)
{
	_ip = ip;
	_port = port;

	_t = std::thread(connThreadFunc, this);
	_t.detach();
}