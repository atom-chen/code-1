/**
 *  ���������߳�
 */

#ifndef _CONNECT_THREAD_H
#define _CONNECT_THREAD_H

#include <thread>
#include <mutex>
#include <string>

#include "BsdSocket.h"

class ConnectThread
{
public:
	ConnectThread(BsdSocket* _ps);
	~ConnectThread(void);

	void start(const std::string& ip, int port);

	void handleConnect();

private:

	BsdSocket* _pSocket;
	std::thread _t;

	std::string _ip;
	int _port;

};

#endif //_CONNECT_THREAD_H