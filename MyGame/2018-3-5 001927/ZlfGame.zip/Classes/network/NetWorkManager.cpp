#include "NetWorkManager.h"
#include "SendThread.h"
#include "ConnectThread.h"
#include "RecvThread.h"
#include "cocos2d.h"
#include "message.h"
#include "Bridge.h"
USING_NS_CC;
using namespace std;

static NetworkManager* _instance = nullptr;

NetworkManager::NetworkManager():
	_bsdSocket(nullptr),
	_sendThread(nullptr),
	_recvThread(nullptr),
	_connThread(nullptr),
	_networkStatus(NETWORK_UNINIT),
	_isInitNetwork(false),
	_sendProtoDataList(0)
{
}

NetworkManager::~NetworkManager()
{
	if(_bsdSocket)
	{
		delete _bsdSocket;
		_bsdSocket = nullptr;
	}

	if(_sendThread)
	{
		delete _sendThread;
		_sendThread = nullptr;
	}

	if(_recvThread)
	{
		delete _recvThread;
		_recvThread = nullptr;
	}

	if(_connThread)
	{
		delete _connThread;
		_connThread = nullptr;
	}

}

NetworkManager* NetworkManager::getInstance()
{
	if(!_instance)
	{
		_instance = new NetworkManager();
		_instance->init();
	}

	return _instance;
}

void NetworkManager::destoryInstance()
{
	if(_instance)
	{
		delete _instance;
		_instance = nullptr;
	}
}

bool NetworkManager::init()
{
	return true;
}

int NetworkManager::initNetwork()
{
	if(_isInitNetwork)
		return 0;

	CCLOG("[network] begin init network");

	_bsdSocket = new BsdSocket();
	//��ʼ��winsock
	int initSocket = _bsdSocket->init();
	if(initSocket == SOCKET_INIT_FAIL)
	{
		CCLOG("[network] init socket fail:%d", _bsdSocket->getError());
		return -1;
	}

	CCLOG("[network] init network success");
	//���������̣߳��������ݵ��̣߳��������ݵ��̡߳����ӵ��߳�
	_sendThread = new SendThread(_bsdSocket);
	_sendThread->start();

	_recvThread = new RecvThread(_bsdSocket);
	_recvThread->start();

	_connThread = new ConnectThread(_bsdSocket);

	setNetworkStatus(NETWORK_INITED);

	_isInitNetwork = true;
	return 0;
}

void NetworkManager::connect(const string& ip, int port)
{
	if(!_isInitNetwork)
		return;

	CCLOG("[network] begin connect server, ip:%s, port:%d", ip.c_str(), port);

	//���ӳɹ���������
	if(getNetworkStatus() == NETWORK_CONNECTED || getNetworkStatus() == NETWORK_BEGIN_CONNECT)
		return;

	setNetworkStatus(NETWORK_BEGIN_CONNECT);

	_bsdSocket->create();
	_connThread->start(ip, port);

}

void NetworkManager::close()
{
	_bsdSocket->closeConnect();
}

void NetworkManager::setNetworkStatus(int status)
{
	unique_lock<mutex> ulc(_statusMutex, defer_lock);
	//����߳�û��  ���Լ���
	if(!ulc.owns_lock())
	{
		ulc.try_lock();
	}

	if(_networkStatus != status)
	{
		_networkStatus = status;
		Bridge::getInstance()->addLuaEvent("update_network_status");
	}

	//����߳�����   ����
	if(ulc.owns_lock())
	    ulc.unlock();

	if(status == NETWORK_CONNECTED)
	{
		CCLOG("[network] notify receive thread");
		_recvThread->wakeUp();
	}
}

int NetworkManager::getNetworkStatus()
{
	unique_lock<mutex> ulc(_statusMutex, defer_lock);
	if(!ulc.owns_lock())
		ulc.try_lock();
	return _networkStatus;
}

void NetworkManager::sendProto(int protoId, const char* protoBody, int protoSize /* = 0 */)
{
	//û���������粻����Э��
	if(_networkStatus != NETWORK_CONNECTED)
	{
		CCLOG("[network] prohibit send proto without connect");
		return;
	}
	CCLOG("[network] add proto %s  id is %d" , protoBody , protoId);
	NetworkSendProtoData* pd = getFreeSendProtoData();
	pd->protoId = protoId;
	pd->fillBody(protoBody, protoSize);
	_sendThread->addProto(pd);
}

void NetworkManager::recycleSendProtoData(NetworkSendProtoData* protoData)
{
	unique_lock<mutex> ulc(_sendListMutex);
	protoData->reset();
	_sendProtoDataList.push_back(protoData);
}

NetworkSendProtoData* NetworkManager::getFreeSendProtoData()
{
	unique_lock<mutex> ulc(_sendListMutex);
	if(_sendProtoDataList.empty())
	{
		NetworkSendProtoData* protoData = NetworkSendProtoData::create();
		return protoData;
	}
	else
	{
		NetworkSendProtoData* protoData = _sendProtoDataList.back();
		_sendProtoDataList.pop_back();
		return protoData;
	}
}

NetworkRecvProtoData* NetworkManager::getFreeRecvProtoData(unsigned int len)
{
	NetworkRecvProtoData* protoData = NetworkRecvProtoData::create(len);
	return protoData;
}