//����Э����ؽṹ
#ifndef NETWORK_PROTO_DATA_H
#define NETWORK_PROTO_DATA_H

#include <string>

/**
 *  ����Э�����ݰ�
 *  ��ʽ:  protoLen:u_int, 
 *        protoId:int,
 *        bodyData:char*
 */
class NetworkProtoData
{
public:
	NetworkProtoData(void);
	virtual ~NetworkProtoData(void);

	static NetworkProtoData* create();

	void release();
	void retain();

	virtual void reset();

	/**
	 *  ��ȡ���е�����
	 */
	virtual char* getContent();
	unsigned int getSize();

	unsigned int getBodySize();

private:
	int _referenceCount;

public:
	/*Э���*/
	short protoId;

	unsigned int size;

protected:

	unsigned int _bodySize;

	/*Э������*/
	char* _content;

	unsigned int _size;
};

//Э�鷢�����ݽṹ
class NetworkSendProtoData : public NetworkProtoData
{
public:
	NetworkSendProtoData(void);
	~NetworkSendProtoData(void);

	static NetworkSendProtoData* create();

	void reset();

	void fillBody(const char* protoBody, int bodySize);

	char* getContent();

};


//Э��������ݽṹ
class NetworkRecvProtoData : public NetworkProtoData
{
public:
	NetworkRecvProtoData(void);
	NetworkRecvProtoData(unsigned int len);
	~NetworkRecvProtoData(void);

	static NetworkRecvProtoData* create();
	static NetworkRecvProtoData* create(unsigned int len);

	void reset();

	void parseBody(const char* buf, unsigned int size);

	/**
	 *  ��ȡ��������
	 */
	char* getBodyBytes();

private:
	char* _bodyBytes;
	unsigned int len;

};

#endif // NETWORK_PROTO_DATA_H