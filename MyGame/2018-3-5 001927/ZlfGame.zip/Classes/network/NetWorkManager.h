#ifndef _NET_WORK_MANAGER_H_
#define _NET_WORK_MANAGER_H_

#include <mutex>
#include <condition_variable>
#include <list>
#include <string>
#include "ProtoData.h"

#include "BsdSocket.h"

class RecvThread;
class SendThread;
class ConnectThread;

class NetworkManager
{
	NetworkManager();
public:
	~NetworkManager();
	/**
	 *  get instance of NetworkManager
	 */
	static NetworkManager* getInstance();
	/**
	 *  destory instance of NetworkManager
	 */
	static void destoryInstance();

	/**
	 *  ��ʼ������
	 */
	int initNetwork();

	void connect(const std::string& ip, int port);
	void close();

	void sendProto(int protoId, const char* protoBody, int protoSize = 0);

	/**
	 * ��������״̬
	 */
	void setNetworkStatus(int status);

	int getNetworkStatus();
protected:
	bool init();
private:
	BsdSocket* _bsdSocket;
	SendThread* _sendThread;
	RecvThread* _recvThread;
	ConnectThread* _connThread;

	std::mutex _sendListMutex;
	std::condition_variable _sendListCond;

	std::mutex _statusMutex;

	std::mutex _freeRecvMutex;
	int _networkStatus;

	bool _isInitNetwork;
private:
	std::list<NetworkSendProtoData*> _sendProtoDataList;
	//list��ȡ�����ݰ�
	NetworkSendProtoData* getFreeSendProtoData();

	std::list<NetworkRecvProtoData*> _recvProtoDataList;

public:	
	//�������ݰ�
	void recycleSendProtoData(NetworkSendProtoData* protoData);
	//��ȡ�µ�recv���ݰ�
	NetworkRecvProtoData* getFreeRecvProtoData(unsigned int len);
};

#endif //_NET_WORK_MANAGER_H_