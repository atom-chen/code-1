/*
	�յ�Э�飬֪ͨlua
*/
#ifndef _BRIDGE_H_
#define _BRIDGE_H_

#include <vector>
#include <map>
#include <list>
#include <mutex>
#include <cstdarg>
#include "message.h"

class Bridge
{
	static Bridge* m_Instance;
	Bridge();
	std::list< ProtoData > m_protoDataList;
	std::list< std::string > m_luaEventList;
	std::mutex m_protoMutex;
	std::mutex m_addMutex;
	std::mutex m_luaeventMutex;
	std::mutex m_eventMutex;
	void handleProtoList();
	void onReciveProto( int tag , std::string protoData );
	void handleLuaEventList();
	void onLuaEvent( std::string eventName );
public:
	void addRecvProtoData( int tag , std::string protoData );
	static Bridge* getInstance();
	static void destoryInstance();
	void update( float dt );
	void addLuaEvent( std::string lua_event );
};

#endif