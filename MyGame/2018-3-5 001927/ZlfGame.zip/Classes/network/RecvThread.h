#ifndef _RECV_THREAD_H_
#define _RECV_THREAD_H_

#include <thread>
#include <mutex>
#include <condition_variable>
#include "BsdSocket.h"
#include "ProtoData.h"

struct Recv_data
{
	int   len;
	char* data;
};

class RecvThread
{
public:
	RecvThread(BsdSocket*);
	~RecvThread();
	void start();
	void handleRecv();
	void wakeUp();
private:

	std::mutex _recvMutex;
	//sleep condition
	std::condition_variable _recvCond;

	std::thread _t;

	bool _readHead;

	bool _keepThread;

	BsdSocket* _pSocket;

	Recv_data _rd;

	char* _recvBodyBuff;

	NetworkRecvProtoData* _pRecvData;

	unsigned int _protoLen;

private:
	int keepRecv(char* buf, int len);

	void recvError();
};

#endif //_RECV_THREAD_H_