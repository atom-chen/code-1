#include "BsdSocket.h"
#include "cocos2d.h"

#ifdef WIN32
#pragma comment(lib, "ws2_32.lib")
#endif

BsdSocket::BsdSocket(void):
	_socket(INVALID_SOCKET)
{
	_isInitLib = false;
}

BsdSocket::~BsdSocket(void)
{
}

int BsdSocket::init()
{
#if defined(WIN32)
	WSADATA wsaData;

	if(!_isInitLib)
	{
		//init winsock dll
	    int ret = WSAStartup(MAKEWORD(2, 0), &wsaData);
	    if(ret != 0)
			return SOCKET_INIT_FAIL; //load dll fail

		_isInitLib = true;
	}
#endif

	return SOCKET_INIT_SUCCESS;
}

int BsdSocket::create(int af, int type, int protocol)
{
	if(_socket != INVALID_SOCKET)
		return _socket;

	_socket = socket(af, type, protocol);
	if(_socket == INVALID_SOCKET)
		return SOCKET_INIT_FAIL;

	return _socket;

}

int BsdSocket::connectServer(const char* ip, unsigned short port)
{
	const static int connect_timeout_time = 10;

	if(_socket == INVALID_SOCKET)
		return SOCKET_ERROR;

	int status = SOCKET_CONNECT_FAIL;

	unsigned long ul = 1;
	int ret = 0;

	//set no-block mode for connect
#ifdef WIN32
	ret = ioctlsocket(_socket, FIONBIO, (unsigned long*)&ul);
#else
	ret = ioctl(_socket, FIONBIO, (unsigned long*)&ul);
#endif

	do
	{
		if(ret != 0)
			break;

		struct sockaddr_in svraddr;
		svraddr.sin_family = AF_INET;
		svraddr.sin_addr.s_addr = inet_addr(ip);
		svraddr.sin_port = htons(port);

		ret = connect(_socket, (struct sockaddr*)&svraddr, sizeof(svraddr));
		if(ret == SOCKET_ERROR)
		{
			int optVal;
            socklen_t len = (socklen_t)sizeof(int);

			struct timeval timeout;
			timeout.tv_sec = connect_timeout_time;
			timeout.tv_usec = 0;

			fd_set set;

			FD_ZERO(&set);
			FD_SET(_socket, &set);

			ret = select((int)_socket + 1, NULL, &set, NULL, &timeout);
			if(ret > 0)
			{
				if(getsockopt(_socket, SOL_SOCKET, SO_ERROR, (char*)&optVal, &len) == 0)
				{
					status = SOCKET_CONNECT_SUCCESS;
				}
				else
				{
					status = SOCKET_CONNECT_TIMEOUT;
				}
			}
			else
			{
				status = SOCKET_CONNECT_TIMEOUT;
			}
		}
		else
		{
			status = SOCKET_CONNECT_SUCCESS;
		}

	} while (0);

	//reset block mode

	ul = 0;
#ifdef WIN32
	ret = ioctlsocket(_socket, FIONBIO, (unsigned long*)&ul);
#else
	ret = ioctl(_socket, FIONBIO, (unsigned long*)&ul);
#endif

	if(status != SOCKET_CONNECT_SUCCESS)
		closeConnect();

	return status;
}

int BsdSocket::sendData(const char* buf, int len)
{
	if(_socket == INVALID_SOCKET)
		return SOCKET_ERROR;

	int bytes = 0;
	while(bytes < len)
	{
		//win32 platform may send bytes less than len
		int result = send(_socket, buf + bytes, len - bytes, 0);
		if(result == SOCKET_ERROR)
			break;

		bytes += result;
	}

	return bytes;
}

int BsdSocket::recvData(char* buf, int len)
{
	/*int count = 0;
	int result = 0;
	do
	{
		result = recv(_socket, buf, len, 0);
		if(result > 0)
		{
			count += result;
			continue;
		}

		if(result == 0)
			break;

		if(count == 0)
			count = result;
		break;
	}while(result > 0);

	return count;*/
	int count = recv(_socket, buf, len, 0);
	return count;
}

int BsdSocket::cleanup()
{
	int ret = 0;
#if defined(WIN32)
	//clean ws2_32.dll
	if(_isInitLib)
	{
	    ret = WSACleanup();
	    if(ret == 0)
			_isInitLib = true;
	}

#endif
	return ret;
}

int BsdSocket::closeConnect()
{
	int ret;
#if defined(WIN32)
	shutdown(_socket, SD_BOTH);
	ret = closesocket(_socket);
#else
    shutdown(_socket, SHUT_RDWR);
	ret = close(_socket);
#endif

	/*if(ret == 0)
		_socket = INVALID_SOCKET;*/
	_socket = INVALID_SOCKET;

	return ret;
}
int BsdSocket::getError()
{
	if(_isInitLib)
	{
#if defined(WIN32)
	return WSAGetLastError();
#else
	return errno;
#endif
	}
	else
	{
		return _lastError;
	}
}

