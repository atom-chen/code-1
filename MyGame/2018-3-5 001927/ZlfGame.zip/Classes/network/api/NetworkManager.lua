
--------------------------------
-- @module NetworkManager
-- @parent_module 

--------------------------------
-- 
-- @function [parent=#NetworkManager] getNetworkStatus 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
-- 
-- @function [parent=#NetworkManager] sendProto 
-- @param self
-- @param #int protoId
-- @param #char protoBody
-- @param #int protoSize
-- @return NetworkManager#NetworkManager self (return value: NetworkManager)
        
--------------------------------
-- 
-- @function [parent=#NetworkManager] getFreeRecvProtoData 
-- @param self
-- @param #unsigned int len
-- @return NetworkRecvProtoData#NetworkRecvProtoData ret (return value: NetworkRecvProtoData)
        
--------------------------------
-- ³õÊ¼»¯ÍøÂç
-- @function [parent=#NetworkManager] initNetwork 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
-- 
-- @function [parent=#NetworkManager] connect 
-- @param self
-- @param #string ip
-- @param #int port
-- @return NetworkManager#NetworkManager self (return value: NetworkManager)
        
--------------------------------
-- ÉèÖÃÍøÂç×´Ì¬
-- @function [parent=#NetworkManager] setNetworkStatus 
-- @param self
-- @param #int status
-- @return NetworkManager#NetworkManager self (return value: NetworkManager)
        
--------------------------------
-- 
-- @function [parent=#NetworkManager] close 
-- @param self
-- @return NetworkManager#NetworkManager self (return value: NetworkManager)
        
--------------------------------
-- 
-- @function [parent=#NetworkManager] recycleSendProtoData 
-- @param self
-- @param #NetworkSendProtoData protoData
-- @return NetworkManager#NetworkManager self (return value: NetworkManager)
        
--------------------------------
-- destory instance of NetworkManager
-- @function [parent=#NetworkManager] destoryInstance 
-- @param self
-- @return NetworkManager#NetworkManager self (return value: NetworkManager)
        
--------------------------------
-- get instance of NetworkManager
-- @function [parent=#NetworkManager] getInstance 
-- @param self
-- @return NetworkManager#NetworkManager ret (return value: NetworkManager)
        
return nil
