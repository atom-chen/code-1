﻿//bsdsocket packing, use with win32 android ios etc platform

#ifndef BSDSOCKET_H
#define BSDSOCKET_H

#if defined(WIN32)
#include <WinSock2.h>
typedef int socklen_t;
#else
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <netinet/in.h>
#include <sys/ioctl.h>
#include <arpa/inet.h>
#include <unistd.h>

//adapter window
#define INVALID_SOCKET -1
#define SOCKET_ERROR -1
typedef int SOCKET;
#endif

#define SOCKET_INIT_SUCCESS 0
#define SOCKET_INIT_FAIL -1

#define SOCKET_CONNECT_FAIL -1
#define SOCKET_CONNECT_SUCCESS 0
#define SOCKET_CONNECT_TIMEOUT 1


//base ipv4 tcp stream socket, block mode
class BsdSocket
{
public:
	BsdSocket(void);
	~BsdSocket(void);

	//init socket
	int init();

	//create socket descriptor
	int create(int af = AF_INET, int type = SOCK_STREAM, int protocol = IPPROTO_TCP);

	//connect server
	int connectServer(const char* ip, unsigned short port);
	//send data
	int sendData(const char* buf, int len);
	//receive data
	int recvData(char* buf, int len);

	//for win32
	int cleanup();

	//close socket
	int closeConnect();

	int getError();

private:
	SOCKET _socket;
	int _lastError;
	bool _isInitLib;
};

#endif  //BSDCOEKT_H

