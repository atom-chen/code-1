#include "lua_cocos2dx_network_auto.hpp"
#include "NetWorkManager.h"
#include "tolua_fix.h"
#include "LuaBasicConversions.h"



int lua_cocos2dx_network_NetworkManager_getNetworkStatus(lua_State* tolua_S)
{
    int argc = 0;
    NetworkManager* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"NetworkManager",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (NetworkManager*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_cocos2dx_network_NetworkManager_getNetworkStatus'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_cocos2dx_network_NetworkManager_getNetworkStatus'", nullptr);
            return 0;
        }
        int ret = cobj->getNetworkStatus();
        tolua_pushnumber(tolua_S,(lua_Number)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "NetworkManager:getNetworkStatus",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_cocos2dx_network_NetworkManager_getNetworkStatus'.",&tolua_err);
#endif

    return 0;
}
int lua_cocos2dx_network_NetworkManager_sendProto(lua_State* tolua_S)
{
    int argc = 0;
    NetworkManager* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"NetworkManager",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (NetworkManager*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_cocos2dx_network_NetworkManager_sendProto'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 2) 
    {
        int arg0;
        const char* arg1;

        ok &= luaval_to_int32(tolua_S, 2,(int *)&arg0, "NetworkManager:sendProto");

        std::string arg1_tmp; ok &= luaval_to_std_string(tolua_S, 3, &arg1_tmp, "NetworkManager:sendProto"); arg1 = arg1_tmp.c_str();
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_cocos2dx_network_NetworkManager_sendProto'", nullptr);
            return 0;
        }
        cobj->sendProto(arg0, arg1);
        lua_settop(tolua_S, 1);
        return 1;
    }
    if (argc == 3) 
    {
        int arg0;
        const char* arg1;
        int arg2;

        ok &= luaval_to_int32(tolua_S, 2,(int *)&arg0, "NetworkManager:sendProto");

        std::string arg1_tmp; ok &= luaval_to_std_string(tolua_S, 3, &arg1_tmp, "NetworkManager:sendProto"); arg1 = arg1_tmp.c_str();

        ok &= luaval_to_int32(tolua_S, 4,(int *)&arg2, "NetworkManager:sendProto");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_cocos2dx_network_NetworkManager_sendProto'", nullptr);
            return 0;
        }
        cobj->sendProto(arg0, arg1, arg2);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "NetworkManager:sendProto",argc, 2);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_cocos2dx_network_NetworkManager_sendProto'.",&tolua_err);
#endif

    return 0;
}
int lua_cocos2dx_network_NetworkManager_getFreeRecvProtoData(lua_State* tolua_S)
{
    int argc = 0;
    NetworkManager* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"NetworkManager",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (NetworkManager*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_cocos2dx_network_NetworkManager_getFreeRecvProtoData'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        unsigned int arg0;

        ok &= luaval_to_uint32(tolua_S, 2,&arg0, "NetworkManager:getFreeRecvProtoData");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_cocos2dx_network_NetworkManager_getFreeRecvProtoData'", nullptr);
            return 0;
        }
        NetworkRecvProtoData* ret = cobj->getFreeRecvProtoData(arg0);
        object_to_luaval<NetworkRecvProtoData>(tolua_S, "NetworkRecvProtoData",(NetworkRecvProtoData*)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "NetworkManager:getFreeRecvProtoData",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_cocos2dx_network_NetworkManager_getFreeRecvProtoData'.",&tolua_err);
#endif

    return 0;
}
int lua_cocos2dx_network_NetworkManager_initNetwork(lua_State* tolua_S)
{
    int argc = 0;
    NetworkManager* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"NetworkManager",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (NetworkManager*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_cocos2dx_network_NetworkManager_initNetwork'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_cocos2dx_network_NetworkManager_initNetwork'", nullptr);
            return 0;
        }
        int ret = cobj->initNetwork();
        tolua_pushnumber(tolua_S,(lua_Number)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "NetworkManager:initNetwork",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_cocos2dx_network_NetworkManager_initNetwork'.",&tolua_err);
#endif

    return 0;
}
int lua_cocos2dx_network_NetworkManager_connect(lua_State* tolua_S)
{
    int argc = 0;
    NetworkManager* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"NetworkManager",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (NetworkManager*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_cocos2dx_network_NetworkManager_connect'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 2) 
    {
        std::string arg0;
        int arg1;

        ok &= luaval_to_std_string(tolua_S, 2,&arg0, "NetworkManager:connect");

        ok &= luaval_to_int32(tolua_S, 3,(int *)&arg1, "NetworkManager:connect");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_cocos2dx_network_NetworkManager_connect'", nullptr);
            return 0;
        }
        cobj->connect(arg0, arg1);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "NetworkManager:connect",argc, 2);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_cocos2dx_network_NetworkManager_connect'.",&tolua_err);
#endif

    return 0;
}
int lua_cocos2dx_network_NetworkManager_setNetworkStatus(lua_State* tolua_S)
{
    int argc = 0;
    NetworkManager* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"NetworkManager",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (NetworkManager*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_cocos2dx_network_NetworkManager_setNetworkStatus'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        int arg0;

        ok &= luaval_to_int32(tolua_S, 2,(int *)&arg0, "NetworkManager:setNetworkStatus");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_cocos2dx_network_NetworkManager_setNetworkStatus'", nullptr);
            return 0;
        }
        cobj->setNetworkStatus(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "NetworkManager:setNetworkStatus",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_cocos2dx_network_NetworkManager_setNetworkStatus'.",&tolua_err);
#endif

    return 0;
}
int lua_cocos2dx_network_NetworkManager_close(lua_State* tolua_S)
{
    int argc = 0;
    NetworkManager* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"NetworkManager",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (NetworkManager*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_cocos2dx_network_NetworkManager_close'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_cocos2dx_network_NetworkManager_close'", nullptr);
            return 0;
        }
        cobj->close();
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "NetworkManager:close",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_cocos2dx_network_NetworkManager_close'.",&tolua_err);
#endif

    return 0;
}
int lua_cocos2dx_network_NetworkManager_recycleSendProtoData(lua_State* tolua_S)
{
    int argc = 0;
    NetworkManager* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"NetworkManager",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (NetworkManager*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_cocos2dx_network_NetworkManager_recycleSendProtoData'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        NetworkSendProtoData* arg0;

        ok &= luaval_to_object<NetworkSendProtoData>(tolua_S, 2, "NetworkSendProtoData",&arg0);
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_cocos2dx_network_NetworkManager_recycleSendProtoData'", nullptr);
            return 0;
        }
        cobj->recycleSendProtoData(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "NetworkManager:recycleSendProtoData",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_cocos2dx_network_NetworkManager_recycleSendProtoData'.",&tolua_err);
#endif

    return 0;
}
int lua_cocos2dx_network_NetworkManager_destoryInstance(lua_State* tolua_S)
{
    int argc = 0;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif

#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertable(tolua_S,1,"NetworkManager",0,&tolua_err)) goto tolua_lerror;
#endif

    argc = lua_gettop(tolua_S) - 1;

    if (argc == 0)
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_cocos2dx_network_NetworkManager_destoryInstance'", nullptr);
            return 0;
        }
        NetworkManager::destoryInstance();
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d\n ", "NetworkManager:destoryInstance",argc, 0);
    return 0;
#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_cocos2dx_network_NetworkManager_destoryInstance'.",&tolua_err);
#endif
    return 0;
}
int lua_cocos2dx_network_NetworkManager_getInstance(lua_State* tolua_S)
{
    int argc = 0;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif

#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertable(tolua_S,1,"NetworkManager",0,&tolua_err)) goto tolua_lerror;
#endif

    argc = lua_gettop(tolua_S) - 1;

    if (argc == 0)
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_cocos2dx_network_NetworkManager_getInstance'", nullptr);
            return 0;
        }
        NetworkManager* ret = NetworkManager::getInstance();
        object_to_luaval<NetworkManager>(tolua_S, "NetworkManager",(NetworkManager*)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d\n ", "NetworkManager:getInstance",argc, 0);
    return 0;
#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_cocos2dx_network_NetworkManager_getInstance'.",&tolua_err);
#endif
    return 0;
}
static int lua_cocos2dx_network_NetworkManager_finalize(lua_State* tolua_S)
{
    printf("luabindings: finalizing LUA object (NetworkManager)");
    return 0;
}

int lua_register_cocos2dx_network_NetworkManager(lua_State* tolua_S)
{
    tolua_usertype(tolua_S,"NetworkManager");
    tolua_cclass(tolua_S,"NetworkManager","NetworkManager","",nullptr);

    tolua_beginmodule(tolua_S,"NetworkManager");
        tolua_function(tolua_S,"getNetworkStatus",lua_cocos2dx_network_NetworkManager_getNetworkStatus);
        tolua_function(tolua_S,"sendProto",lua_cocos2dx_network_NetworkManager_sendProto);
        tolua_function(tolua_S,"getFreeRecvProtoData",lua_cocos2dx_network_NetworkManager_getFreeRecvProtoData);
        tolua_function(tolua_S,"initNetwork",lua_cocos2dx_network_NetworkManager_initNetwork);
        tolua_function(tolua_S,"connect",lua_cocos2dx_network_NetworkManager_connect);
        tolua_function(tolua_S,"setNetworkStatus",lua_cocos2dx_network_NetworkManager_setNetworkStatus);
        tolua_function(tolua_S,"close",lua_cocos2dx_network_NetworkManager_close);
        tolua_function(tolua_S,"recycleSendProtoData",lua_cocos2dx_network_NetworkManager_recycleSendProtoData);
        tolua_function(tolua_S,"destoryInstance", lua_cocos2dx_network_NetworkManager_destoryInstance);
        tolua_function(tolua_S,"getInstance", lua_cocos2dx_network_NetworkManager_getInstance);
    tolua_endmodule(tolua_S);
    std::string typeName = typeid(NetworkManager).name();
    g_luaType[typeName] = "NetworkManager";
    g_typeCast["NetworkManager"] = "NetworkManager";
    return 1;
}
TOLUA_API int register_all_cocos2dx_network(lua_State* tolua_S)
{
	tolua_open(tolua_S);
	
	tolua_module(tolua_S,nullptr,0);
	tolua_beginmodule(tolua_S,nullptr);

	lua_register_cocos2dx_network_NetworkManager(tolua_S);

	tolua_endmodule(tolua_S);
	return 1;
}

