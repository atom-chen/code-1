#include "cocos2d.h"
#include "NetWorkManager.h"
#include "RecvThread.h"
#include "Bridge.h"
#include "message.h"

#ifdef WIN32
#else
#include <unistd.h>
#endif

USING_NS_CC;

static void recvThreadFunc( void* ptr )
{
	RecvThread* self = ( RecvThread* )ptr;
	self->handleRecv();
}

RecvThread::RecvThread(BsdSocket* socket):
	_pSocket(socket),
	_readHead(false),
	_protoLen(0),
	_keepThread(true),
	_pRecvData(nullptr),
	_recvBodyBuff(nullptr)
{
	_rd.len = 0;
	_rd.data = "";
	_recvBodyBuff = new char[PROTO_DATA_RECV_BUF_SIZE];
}

RecvThread::~RecvThread(void)
{
	if(_recvBodyBuff != nullptr)
	{
		delete [] _recvBodyBuff;
		_recvBodyBuff = nullptr;
	}
}

void RecvThread::start()
{
	_t = std::thread(recvThreadFunc, this);
	_t.detach();
}

void RecvThread::handleRecv()
{
	while (_keepThread)
	{
		std::unique_lock< std::mutex > ul( _recvMutex );
		while(NetworkManager::getInstance()->getNetworkStatus() != NETWORK_CONNECTED)
		{
			CCLOG( "recv wait" );
			_recvCond.wait(ul);
		}
		//read len first
		if (_protoLen == 0)
		{
			char lenBuf[PROTO_DATA_LEN_SIZE] = {0};
			int ret = keepRecv(lenBuf, PROTO_DATA_LEN_SIZE);
			if(ret == SOCKET_ERROR)
			{
				recvError();
			}
			else
			{
				int len = 0;
				::memcpy(&len, lenBuf, PROTO_DATA_LEN_SIZE);
				_protoLen = ntohl(len);
			}
		}
		if(!_pRecvData)
		{
			_pRecvData = NetworkManager::getInstance()->getFreeRecvProtoData(_protoLen);
			_pRecvData->size = _protoLen;
		}
		if (_pRecvData->size == 0)
		{
			char lenBuf[PROTO_DATA_LEN_SIZE] = {0};
			int ret = keepRecv(lenBuf, PROTO_DATA_LEN_SIZE);
			if(ret == SOCKET_ERROR)
			{
				recvError();
			}
			else
			{
				int len = 0;
				::memcpy(&len, lenBuf, PROTO_DATA_LEN_SIZE);
				_pRecvData->size = ntohl(len);
			}
		}
		else
		{
			//����̫��
			if(_pRecvData->size > PROTO_DATA_RECV_BUF_SIZE)
			{
				_pRecvData->size = 0;
				continue;
			}
			::memset(_recvBodyBuff, 0, PROTO_DATA_RECV_BUF_SIZE);
			int ret = keepRecv(_recvBodyBuff, _pRecvData->size);
			if(ret == SOCKET_ERROR)
			{
				recvError();
			}
			else
			{
				//�������
				_pRecvData->parseBody(_recvBodyBuff, _pRecvData->size);
				CCLOG( "recv id is %d body is %s" , _pRecvData->protoId , _pRecvData->getBodyBytes() );
				Bridge::getInstance()->addRecvProtoData( _pRecvData->protoId , _pRecvData->getBodyBytes() );
				_pRecvData = nullptr;
				_protoLen = 0;
#ifdef WIN32
				::Sleep(10);
#else
				usleep(10000);
#endif
			}
		}
	}
}

void RecvThread::wakeUp()
{
	CCLOG("wake up Recv thread");
	_recvCond.notify_one();
}

int RecvThread::keepRecv(char* buf, int len)
{
	int left = 0;
	::memset(buf, 0, len);
	while(true)
	{
		CCLOG( "bytes is %d %d" , len , left );
		int bytes = _pSocket->recvData(buf + left, len - left);
		if(bytes <= 0)
		{
			return SOCKET_ERROR;
		}
		if(bytes > 0)
		{
			left += bytes;
			if(left >= len)
			{
				return len;
			}
		}
	}
}

void RecvThread::recvError()
{
	CCLOG("network error");
	NetworkManager::getInstance()->setNetworkStatus( NETWORK_CONNECT_LOST );
	NetworkManager::getInstance()->close();
}