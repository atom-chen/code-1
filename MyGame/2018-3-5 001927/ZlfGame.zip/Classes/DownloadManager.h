#ifndef _DOWNLOAD_MANAGER_H_
#define _DOWNLOAD_MANAGER_H_

#include "cocos2d.h"
#include "extensions/cocos-ext.h"
#include "network/HttpClient.h"
#include <iostream>
#include <list>
#include <vector>
using namespace std;
USING_NS_CC;

struct down_dt
{
	std::string name;
	std::string down_url;
};

class DownloadManager {
	DownloadManager();
	static DownloadManager* m_pInstance;
	std::list< down_dt > m_down_list;
	bool m_downing;
public:
	~DownloadManager();
	static DownloadManager* getInstance();
	std::string m_path;
	void addDownTask( std::string save_name , std::string img_url );
	void downImg( std::string save_name , std::string img_url );
	void start();
	void onCompleted( network::HttpClient* sender, network::HttpResponse* response );
};

#endif