LoginView = class("LoginView", LayerBase)


function LoginView:create()
	local ret = LoginView.new()
	return ret
end

function LoginView:init()

	print("this is hot update file")
	
end
