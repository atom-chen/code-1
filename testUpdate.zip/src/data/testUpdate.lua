testUpdate = {}
testUpdate.tt = function()
	print("这是热更文件")
end

return testUpdate